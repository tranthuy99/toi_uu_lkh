from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')
from collections import defaultdict

def default():
    return []

def read_data(filename):
    with open(filename,'r') as f:
        n, k = [int(i) for i in f.readline().strip().split(' ')]
        d = []
        for i in range(n + 2*k):
            di = [int(i) for i in f.readline().strip().split(' ')]
            d.append(di)
        r = [int(i) for i in f.readline().strip().split(' ')]
        c=[int(i) for i in f.readline().strip().split(' ')]
    return n, k, d, r, c

N, K, d, r, c = read_data('data_cvrp.txt')
print(N,'\n', K,'\n', d,'\n', r,'\n', c)
INF =solver.infinity()
x=[[[solver.IntVar(0, 1, 'x['+str(k)+', '+str(i)+', '+str(j)+']') for j in range(N+2*K)] for i in range(N+2*K)] for k in range(K)]

y = [[solver.IntVar(0, 10, 'y['+str(k)+', '+str(i)+']') for i in range(N+2*K)] for k in range(K)]

z = [solver.IntVar(0, K-1, f'z[{i}]') for i in range(N+2*K)]

B = [(i, j) for i in range(N+2*K) for j in range(N+2*K)]
print(B)
F1 = [(i, k+N) for i in range(N+2*K) for k in range(K)]
print(F1)
F2 = [(k+K+N, i) for i in range(N+2*K) for k in range(K)]
print(F2)
F3 = [(i, i) for i in range(N+2*K)]
print(F3)
A = list(set(B)-set(F1) -set(F2)-set(F3))
print(A)
A1 = defaultdict(default)
A2 = defaultdict(default)
for (i, j) in A:
    A1[i].append(j)
    A2[j].append(i)

print(A1, A2)

for i in range(N):
    cstr= solver.Constraint(1, 1)
    for j in A1[i]:
        for k in range(K):
            cstr.SetCoefficient(x[k][i][j], 1)
          

    cstr= solver.Constraint(1, 1)
    for j in A2[i]:
        for k in range(K):
            cstr.SetCoefficient(x[k][j][i], 1)
               
for i in range(N):
    for k in range(K):
        cstr=solver.Constraint(0, 0)
        for j in A2[i]:
            cstr.SetCoefficient(x[k][j][i], 1)
        for j in A1[i]:
            cstr.SetCoefficient(x[k][i][j], -1)

for k in range(K):
    cstr=solver.Constraint(1, 1)
    for j in range(N):
        cstr.SetCoefficient(x[k][k+N][j], 1)

    cstr=solver.Constraint(1, 1)
    for j in range(N):
        cstr.SetCoefficient(x[k][j][k+K+N], 1)
M=1000000000
for (i, j) in A:
    for k in range(K):
        cstr=solver.Constraint(-M, INF)
        cstr.SetCoefficient(x[k][i][j], -M)
        cstr.SetCoefficient(z[i], 1)
        cstr.SetCoefficient(z[j], -1)

        cstr=solver.Constraint(-M, INF)
        cstr.SetCoefficient(x[k][i][j], -M)
        cstr.SetCoefficient(z[i], -1)
        cstr.SetCoefficient(z[j], 1)

        cstr=solver.Constraint(-M+r[j], INF)
        cstr.SetCoefficient(x[k][i][j], -M)
        cstr.SetCoefficient(y[k][j], 1)
        cstr.SetCoefficient(y[k][i], -1)

        cstr=solver.Constraint(-M-r[j], INF)
        cstr.SetCoefficient(x[k][i][j], -M)
        cstr.SetCoefficient(y[k][i], 1)
        cstr.SetCoefficient(y[k][j], -1)



for k in range(K):
    cstr=solver.Constraint(0, c[k])
    cstr.SetCoefficient(y[k][k+K+N], 1)

for  k in range(K):
    cstr=solver.Constraint(0,  0)
    cstr.SetCoefficient(y[k][k+N], 1)

for k in range(K):
    cstr=solver.Constraint(k,k)
    cstr.SetCoefficient(z[k+N], 1)

    cstr=solver.Constraint(k, k)
    cstr.SetCoefficient(z[k+K+N], 1)
    #cstr.SetCoefficient(z[k+N], -1)

obj=solver.Objective()
for k in range(K):
    for (i, j) in A:
        obj.SetCoefficient(x[k][i][j], d[i][j])
# obj.SetMinimization()
result_status = solver.Solve()
# The problem has an optimal solution.
assert result_status == pywraplp.Solver.OPTIMAL
print(solver.Objective().Value())
print('*****************')
for k in range(K):
    for (i, j) in A:
        # print('*  ',end='')
        if x[k][i][j].solution_value()==1:
            print(f'x[{k}][{i}][{j}] : {x[k][i][j].solution_value()} \nz[{i}]: {z[i].solution_value()}\nz[{j}]: {z[j].solution_value()}')

#chua chay duoc
