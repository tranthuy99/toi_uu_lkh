package localsearch.domainspecific.packing.algorithms;

import localsearch.domainspecific.packing.models.Model3D;

public class GreedyConstructive {

	private Model3D model;
	
	public void solve(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
