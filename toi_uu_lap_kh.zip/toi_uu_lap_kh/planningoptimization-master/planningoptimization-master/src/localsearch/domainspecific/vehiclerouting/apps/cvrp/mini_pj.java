package localsearch.domainspecific.vehiclerouting.apps.cvrp;

import java.util.ArrayList;

import localsearch.domainspecific.vehiclerouting.vrp.neighborhoodexploration.INeighborhoodExplorer;
import java.io.File;
import java.util.*;

import localsearch.domainspecific.vehiclerouting.vrp.ConstraintSystemVR;
import localsearch.domainspecific.vehiclerouting.vrp.IFunctionVR;
import localsearch.domainspecific.vehiclerouting.vrp.VRManager;
import localsearch.domainspecific.vehiclerouting.vrp.VarRoutesVR;
import localsearch.domainspecific.vehiclerouting.vrp.entities.ArcWeightsManager;
import localsearch.domainspecific.vehiclerouting.vrp.entities.Point;
import localsearch.domainspecific.vehiclerouting.vrp.functions.AccumulatedEdgeWeightsOnPathVR;
import localsearch.domainspecific.vehiclerouting.vrp.functions.LexMultiFunctions;
import localsearch.domainspecific.vehiclerouting.vrp.functions.MaxVR;
import localsearch.domainspecific.vehiclerouting.vrp.invariants.AccumulatedWeightEdgesVR;
import localsearch.domainspecific.vehiclerouting.vrp.neighborhoodexploration.GreedyOnePointMoveExplorer;
import localsearch.domainspecific.vehiclerouting.vrp.search.GenericLocalSearch;

public class mini_pj {
    int K;// number of routes
	int N;// number of clients
	int[] d; // thoi gian phu vu moi khach hang
	int[][] c; // ma tran thoi gian
	ArrayList<Point> start;
	ArrayList<Point> end;
	ArrayList<Point> clientPoints;
	ArrayList<Point> allPoints;
	ArcWeightsManager awm;// luu tru trong so tren canh noi giua cac point
	// NodeWeightsManager nwmm;// luu tru trong so tren cac point
	
	HashMap<Point, Integer> mapPoint2ID;
	
	// modelling
	VRManager mgr;
	VarRoutesVR XR;// bien loi giai (luu tap cac route)
	// ConstraintSystemVR CS;
	LexMultiFunctions F;
	IFunctionVR obj;
	IFunctionVR y;
	
	IFunctionVR[] cost;// cost[k] la chieu dai cua route thu k
	
	public void readData(String fn){
		try{
			Scanner in = new Scanner(new File(fn));
			N = in.nextInt();
			K = in.nextInt();
			d = new int[N+1]; 
			c = new int[N+1][N+1];
			d[0] = 0;
			for(int i = 1; i <= N; i++){
				d[i] = in.nextInt();
			}
			for (int i=0; i<=N; i++){
				for (int j=0; j<=N;j++){
                    if (i!=j)	c[i][j] = in.nextInt()+d[j];
                    else {
                        in.nextInt();
                        c[i][j] = 0;
                    }
				}
			}
			in.close();
			System.out.println(N+"  "+ K);
			for (int i =0; i<=N; i++)
				System.out.print(d[i]+"  ");
			System.out.println();
			for (int i=0; i<=N; i++){
				for (int j=0; j<=N;j++){
					System.out.print(c[i][j]+"  ");
				}
				System.out.println();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void mapping(){
		// map from raw data to objects
		start = new ArrayList<Point>();
		end = new ArrayList<Point>();
		clientPoints = new ArrayList<Point>();
		allPoints = new ArrayList<Point>();
		
		mapPoint2ID = new HashMap<Point, Integer>();
		// khoi tao cac diem bat dau va ket thuc cua cac xe (route)
		for(int k = 1; k <= K; k++){
			Point s = new Point(0);
			Point t = new Point(0);
			start.add(s);
			end.add(t);
			allPoints.add(s);
			allPoints.add(t);
			mapPoint2ID.put(s, 0);
			mapPoint2ID.put(t,0);
		}
		
		// khoi tao cac diem clients
		for(int i = 1; i <= N; i++){
			Point p = new Point(i);
			clientPoints.add(p);
			allPoints.add(p);
			mapPoint2ID.put(p, i);
		}
		
		// khoi tao object quan ly trong so
		awm = new ArcWeightsManager(allPoints);
				
		for(Point p: allPoints){
			for(Point q: allPoints){
				int ip = mapPoint2ID.get(p);
				int iq = mapPoint2ID.get(q);
				awm.setWeight(p,q, c[ip][iq]);
			}
		}
	
	}
	
	public void stateModel(){
		mgr = new VRManager();
		XR = new VarRoutesVR(mgr);
		for(int i = 0; i < start.size(); i++){
			Point s = start.get(i);
			Point t = end.get(i);
			XR.addRoute(s, t);// them 1 route vao phuong an (s --> t)
		}
		for(Point p: clientPoints)
			XR.addClientPoint(p);// khai bao XR co the se di qua diem p
		
	
		AccumulatedWeightEdgesVR accW = new AccumulatedWeightEdgesVR(XR, awm);
			
		cost = new IFunctionVR[K];
		for(int k =1; k <= K; k++){
			Point tk = XR.endPoint(k);
			cost[k-1] = new AccumulatedEdgeWeightsOnPathVR(accW, tk);
		}

		
		obj = new  MaxVR(cost);// tong khoang cach di chuyen cua K xe (route)
		F = new LexMultiFunctions();
		F.add(obj);		
		mgr.close();
	}

	
	public void init(){
		Point s = XR.startPoint(1);
		for(int i = 0; i < clientPoints.size(); i++){
			Point p = clientPoints.get(i);
			mgr.performAddOnePoint(p, s);
			s = p;
		}
	}

	
	public void search(){
		ArrayList<INeighborhoodExplorer> NE = new ArrayList<INeighborhoodExplorer>();
		NE.add(new GreedyOnePointMoveExplorer(XR, F));		
		GenericLocalSearch se = new GenericLocalSearch(mgr);
		se.setNeighborhoodExplorer(NE);
		se.setObjectiveFunction(F);
		se.setMaxStable(50);
		se.search(20, 3000);	
        System.out.println(XR.toString());
	}
	
	
	public static void main(String[] args) {
		mini_pj A = new mini_pj();
		A.readData("data/cvrp/Test_instance_bug.txt");
        // A.readData("data/cvrp/data_N10_K3.txt");
		A.mapping();
		A.stateModel();
		A.search();
        
	
	}
}
