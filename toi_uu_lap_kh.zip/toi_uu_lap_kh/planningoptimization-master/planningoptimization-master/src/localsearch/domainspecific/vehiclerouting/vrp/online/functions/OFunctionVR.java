package localsearch.domainspecific.vehiclerouting.vrp.online.functions;

import localsearch.domainspecific.vehiclerouting.vrp.IFunctionVR;
import localsearch.domainspecific.vehiclerouting.vrp.online.invariants.OInvariantVR;

public interface OFunctionVR extends IFunctionVR, OInvariantVR {
	
}
