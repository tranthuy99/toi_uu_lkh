from numpy import random
# ../../../../../../data/cvrp/
def gendata(N, K):
    with open(f'data_N{N}_K{K}.txt', 'w') as f:
        f.write(f'{N} {K}\n')
        for i in range(N):
            f.write(f'{random.randint(1, 50)} ')
        f.write('\n')
        for i in range(N+1):
            for j in range(N+1):
                if i==j:
                    f.write('0 ')
                else:
                    f.write(f'{random.randint(1, 100)} ')
            f.write('\n')
# gendata(10, 3)
# gendata(15, 3)
# gendata(20, 4)
# gendata(50, 5)
# gendata(50, 10)
# gendata(100, 10)
# gendata(100, 8)
# gendata(150, 10)
# gendata(200, 20)
gendata(20, 5)
gendata(30, 10)
