package localsearch.domainspecific.vehiclerouting.apps.cvrp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readdata {
    public static void main(String[] args) throws FileNotFoundException{
        
            File text = new File("data_N15_K3.txt");
     
            //Creating Scanner instnace to read File in Java
            Scanner scnr = new Scanner(text);
         
            //Reading each line of file using Scanner class
            int lineNumber = 1;
            while(scnr.hasNextLine()){
                String line = scnr.nextLine();
                System.out.println("line " + lineNumber + " :" + line);
                lineNumber++;
            }      
       
        }}  
     
    
    
    
    // Read more: https://www.java67.com/2012/11/how-to-read-file-in-java-using-scanner-example.html#ixzz6vBcdSsVb
        // int N = (int)in.nextInt();
        // String K = in.nextLine();
        // int[] d = new int[N+1]; 
        // int[][] c = new int[N+1][N+1];
        // d[0] = 0;
        // for(int i = 1; i <= N; i++){
        //     d[i] = in.nextInt();
        // }
        // for (int i=0; i<=N; i++){
        //     for (int j=0; j<=N;j++){
        //         if (i!=j)	c[i][j] = in.nextInt()+d[j];
        //         else {
        //             in.nextInt();
        //             c[i][j] = 0;
        //         }
        //     }
        // }
        // in.close();
        // System.out.println("  "+ K);
        // for (int i =0; i<=N; i++)
        //     System.out.print(d[i]+"  ");
        // System.out.println();
        // for (int i=0; i<=N; i++){
        //     for (int j=0; j<=N;j++){
        //         System.out.print(c[i][j]+"  ");
        //     }
        
        
    
        

    

