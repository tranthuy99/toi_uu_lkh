package localsearch.domainspecific.vehiclerouting.vrp;

public class Constants {
	public static final int NULL_POINT = -1;
	public static final int MAX_INT = 2147483647;
}
