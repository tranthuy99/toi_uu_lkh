from ortools.linear_solver import pywraplp

from collections import defaultdict
from pprint import pprint
import time
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('-f', "--filename", help="data file name")
args = parser.parse_args()

def default():
    return []

def read(filename):
    with open(filename, 'r') as f:
        N, K = [int(i) for i in f.readline().split()]
        d = [0]
        d.extend([int(i) for i in f.readline().split()])
        t = [[int(i) for i in f.readline().split()] for _ in range(N+1)]
        for i in range(N+1):
            for j in range(N+1):
                if i!=j:
                    t[i][j]+=d[j]
        return N, K, t
N, K, t = read(args.filename)

c = [[0 for i in range(N+2*K)] for j in range(N+2*K)]
for i in range(N):
    for j in range(N):
        c[i][j] = t[i+1][j+1]
for i in range(N, N+2*K):
    for j in range(N):
        if j< N:
            c[i][j] = t[0][j+1]
            c[j][i] = t[j+1][0]


M=1e9


B = [(i, j) for i in range(N+2*K) for j in range(N+2*K)]
F1 = [(i, k+N) for i in range(N+2*K) for k in range(K)]
F2 = [(k+K+N, i) for i in range(N+2*K) for k in range(K)]
F3 = [(i, i) for i in range(N+2*K)]
A = list(set(B)-set(F1) -set(F2)-set(F3))
A1 = defaultdict(default)
A2 = defaultdict(default)
for (i, j) in A:
    A1[i].append(j)
    A2[j].append(i)

def createvar(N, K, c):
    solver = pywraplp.Solver.CreateSolver('CBC')
    INF =solver.infinity()
    x=[[[solver.IntVar(0, 1, 'x['+str(k)+', '+str(i)+', '+str(j)+']') for j in range(N+2*K)] for i in range(N+2*K)] for k in range(K)]
    g = solver.IntVar(0, INF, 'g')
    z = [solver.IntVar(0, K-1, f'z[{i}]') for i in range(N+2*K)]
    return x, z, g, INF, solver
    
def createXconstraint(N,K, x, solver):
    for i in range(N):
        cstr= solver.Constraint(1, 1)
        for j in A1[i]:
            for k in range(K):
                cstr.SetCoefficient(x[k][i][j], 1)

        cstr= solver.Constraint(1, 1)
        for j in A2[i]:
            for k in range(K):
                cstr.SetCoefficient(x[k][j][i], 1)
       
    for i in range(N):
        for k in range(K):
            cstr=solver.Constraint(0, 0)
            for j in A2[i]:
                cstr.SetCoefficient(x[k][j][i], 1)
            for j in A1[i]:
                cstr.SetCoefficient(x[k][i][j], -1)

    for k in range(K):
        cstr=solver.Constraint(1, 1)
        for j in range(N):
            cstr.SetCoefficient(x[k][k+N][j], 1)

        cstr=solver.Constraint(1, 1)
        for j in range(N):
            cstr.SetCoefficient(x[k][j][k+K+N], 1)


def createZconstraint(N, K, x, z, INF, solver):
    for k in range(K):
        cstr=solver.Constraint(k,k)
        cstr.SetCoefficient(z[k+N], 1)

        cstr=solver.Constraint(k, k)
        cstr.SetCoefficient(z[k+K+N], 1)

    for (i, j) in A:
        for k in range(K):
            cstr=solver.Constraint(k-M, M+k)
            cstr.SetCoefficient(x[k][i][j], -M)
            cstr.SetCoefficient(z[i], 1)
            
            cstr=solver.Constraint(-k-M, M+k)
            cstr.SetCoefficient(x[k][i][j], -M)
            cstr.SetCoefficient(z[i], -1)

            cstr=solver.Constraint(-M, INF)
            cstr.SetCoefficient(x[k][i][j], -M)
            cstr.SetCoefficient(z[i], 1)
            cstr.SetCoefficient(z[j], -1)

            cstr=solver.Constraint(-M, INF)
            cstr.SetCoefficient(x[k][i][j], -M)
            cstr.SetCoefficient(z[i], -1)
            cstr.SetCoefficient(z[j], 1)



def createGconstraint(N, K, x, g, INF, solver):
    for k in range(K):
        cstr = solver.Constraint(0, INF)
        cstr.SetCoefficient(g, 1)
        for (i, j) in A:
            cstr.SetCoefficient(x[k][i][j], -c[i][j])


def createObj(g, solver):
    obj=solver.Objective()
    obj.SetCoefficient(g, 1)
    obj.SetMinimization()


def extractCycle(y, s):
    S=set()
    C=[]
    i=s
    C.append(s)
    S.add(s)
    while True:
        i = findNext(y, i)
        if i == -1:
            return []
        if i in S:
            return C
        else:
            S.add(i)
            C.append(i)

def findNext(y, s):
    for k in range(K):
        for (i, j) in A:
            if y[k][s][j] > 0:
                return j
    return -1

def createSECconstraint(N, K, c, x, solver):
    
    cstr = solver.Constraint(0, 1)
    for k in range(K):
        for i in [0,16]:
            for j in [0, 16]:
                if i!=j:
                    cstr.SetCoefficient(x[k][i][j], 1)

def solveDynamicSEC(N, K, c):
    x, z, g, INF, solver = createvar(N, K, c)
    createXconstraint(N, K, x, solver)
    createZconstraint(N, K, x, z,INF, solver)
    createGconstraint(N, K, x, g, INF, solver)
    createSECconstraint(N, K, c, x, solver)
    createObj(g, solver)
    result_status = solver.Solve()
    assert result_status==pywraplp.Solver.OPTIMAL
    print('object = ', solver.Objective().Value())
    y=[[[0 for j in range(N+2*K)] for i in range(N+2*K)] for k in range(K)]
    for k in range(K):
        for (i, j) in A:
            y[k][i][j] = x[k][i][j].solution_value()
    return y




import time
t0=time.time()
y = solveDynamicSEC(N, K, c)
print(f'time to OPTIMAL : {round(time.time()-t0, 3)}')
for k in range(K):
    t = k+N
    print(f'Buu ta {k} : {t}', end='')
    while t!=k+K+N:
        for j in A1[t]:
            if y[k][t][j]>0:
                print(f' --> {j}', end='')
                t=j
                break
    print('\n')