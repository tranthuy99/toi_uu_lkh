package localsearch.domainspecific.vehiclerouting.apps.sharedaride.Util;

public class Request {
	int id;
	int pickupId;
	int deliveryId;
	int earlyPickupTime;
	int latePickupTime;
	int earlyDeliveryTime;
	int lateDeliveryTime;
	
}
