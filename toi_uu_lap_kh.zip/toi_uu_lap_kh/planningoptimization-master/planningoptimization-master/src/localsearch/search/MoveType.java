package localsearch.search;

public enum MoveType {
	OneVariableValueAssignment,
	TwoVariablesSwap
}
