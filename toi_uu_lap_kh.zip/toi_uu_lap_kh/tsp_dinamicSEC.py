from ortools.linear_solver import pywraplp
import numpy as np 
import random


def genData(filename, n):
    f=open(filename, 'w')
    f.write(str(n)+'\n')
    for i in range(n):
        s=''
        for j in range(n):
            x=random.randint(1,50)
            s=s+str(x)+' '
        s=s+'\n'
        f.write(s)
    f.close()

def input(filename):
    c=[]
    with open(filename, 'r') as f:
        n=int(f.readline())
        
        for i, con in enumerate(f.readlines()):
            c.append([int(x) for x in con.strip().split(' ')])
    return n, c

#n, c=input("data_10.txt")
c=[[0,6,4,2],[5,0,6,1],[1,2,0,8],[3,2,5,0]]
n=len(c)

def CreateSolveAndVariable(n, c):
    solver=pywraplp.Solver.CreateSolver('CBC')
    x={}
    for i in range(n):  
        for j in range(n):
            if i!=j:
                x[i, j]=solver.IntVar(0, 1, 'x(' +str(i)+' , '+str(j)+')')
    return x, solver

def CreateFlowConstraint(n,solver, x):
    #flow balance constraint
    for j in range(n):
        cstr=solver.Constraint(1, 1)
        for i in range(n):
            if i!=j:
                cstr.SetCoefficient(x[i, j], 1)
        cstr=solver.Constraint(1, 1)
        for i in range(n):
            if i!=j:
                cstr.SetCoefficient(x[j, i], 1)

def CreateSECConstraint(solver, x, SEC):
    #SEC
    for s in SEC:
        print('SEC : ', s)
        cstr=solver.Constraint(0,len(s)-1)
        for i in s:
            for j in s:
                if i!=j:
                    cstr.SetCoefficient(x[i,j], 1)




def CreateObjective(n, c, solver, x):
    #obj
    obj=solver.Objective()
    for i in range(n):
        for j in range(n):
            if j!=i:
                obj.SetCoefficient(x[i, j], c[i][j])
    obj.SetMinimization()



def SolveDynSEC(n, c, SEC):
    x, solver=CreateSolveAndVariable(n, c)
    CreateFlowConstraint(n, solver, x)
    CreateSECConstraint(solver, x, SEC)
    CreateObjective(n, c, solver, x)
    result_status=solver.Solve()
    assert result_status==pywraplp.Solver.OPTIMAL
    print('object = ', solver.Objective().Value())

    y=np.array([[0 for i in range(n)] for j in range(n)])
    for i in range(n):
        for j in range(n):
            if i !=j:
                y[i,j]=x[i, j].solution_value()
    return y

def FindNext(y, s):
    for i in range(n):
        if i !=s and y[s, i]>0:
            return i
    return -1
        

def ExtractCycle(y, s):
    S=set()
    C=[]
    i=s
    C.append(s)
    S.add(s)
    print('extractCycle, s= ', s)
    #PrintSol(y, 4)
    while True:
        i =FindNext(y, i)
        if i==-1:
            return []
        if i in S:
            return C
        else:
            S.add(i)
            C.append(i)



def SolveTSPDynSEC(n, c):
    SEC=[]
    while(True):
        y=SolveDynSEC(n, c, SEC)
        mark=[False for v in range(n)]
        for s in range(n):
            if mark[s]==False:
                C=ExtractCycle(y, s)
                print('extractCycle ', C, end='\n\n')
                if len(C)==n:
                    return C
                else:
                    SEC.append(C)
                    for e in C:
                        mark[e]=True


print(SolveTSPDynSEC(n, c))



