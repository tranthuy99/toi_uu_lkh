from ortools.sat.python import cp_model

n=4
model=cp_model.CpModel()

x=[model.NewIntVar(0, n-1, 'x['+str(i)+']') for i in range(n)]
y1=[model.NewIntVar(0,  2*n-2, 'y1['+str(i)+']') for i in range(n)]
y2=[model.NewIntVar(0,  2*n-2, 'y2['+str(i)+']') for i in range(n)]

for i in range(n):
    model.Add(y1[i]==x[i]+i)
    model.Add(y2[i]==x[i]-i+n-1)

model.AddAllDifferent(x)
model.AddAllDifferent(y1)
model.AddAllDifferent(y2)

solver=cp_model.CpSolver()
status=solver.Solve(model)

if status==cp_model.OPTIMAL:
    print('found')
for i in range(n):
    print(solver.Value(x[i]))