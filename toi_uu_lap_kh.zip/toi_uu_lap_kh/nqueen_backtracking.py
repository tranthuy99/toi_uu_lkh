def check(v, k):
    for i in range(k):
        if x[i]==v:
            return False
        if x[i]+i==v+k:
            return False
        if x[i]-i==v-k:
            return False
    return True

def solution():
    global found 
    found=True
    print('found')
    print(x)

def Try(k):
    if found:
        return
    for v in range(n):
        if check(v, k):
            x[k]=v
            if k==n-1:
                solution()
            else: 
                Try(k+1)
n=20

x=[0 for _ in range(n)]
found=False
Try(0)