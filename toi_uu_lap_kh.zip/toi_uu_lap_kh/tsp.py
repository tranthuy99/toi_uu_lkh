import numpy as np 
import 

cmin=1e9

def readfile(filename):
    global n, c 
    with open(filename) as f:
        n=len(f)
        c=[[int(i) for i in line.split(' ')] for line in f]
    return n, c

n, c = readfile('input.txt')

T=[]