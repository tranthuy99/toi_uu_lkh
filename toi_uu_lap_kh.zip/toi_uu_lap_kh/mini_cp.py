from ortools.sat.python import cp_model
from pprint import pprint
import numpy as np
model = cp_model.CpModel()

def read_data(filename):
    with open(filename, 'r') as f:
        N, K = [int(i) for i in f.readline().split()]
        d1 = [int(i) for i in f.readline().split()]
        t = [[int(i) for i in f.readline().split()] for _ in range(N+1)]
    return N, K, d1, t
N, K, d1, t = read_data('data.txt')

c = [[0 for i in range(N+2*K)] for j in range(N+2*K)]
for i in range(N):
    for j in range(N):
        c[i][j] = t[i+1][j+1]
for i in range(N, N+2*K):
    for j in range(N):
        if j< N:
            c[i][j] = t[0][j+1]
            c[j][i] = t[j+1][0]
pprint(c)
print('*'*100)

# ma tran d
d = [0 for i in range(N+2*K)]
for i in range(N):
    d[i] = d1[i]
pprint(d)
print('*'*100)

serve_time = 0
for i in d:
    serve_time+=i
serve_time+=np.sum(c)


x = [model.NewIntVar(0, N+2*K-1, f'x[{i}]') for i in range(N+K)]
IR = [model.NewIntVar(0, K-1, f'IR[{i}]') for i in range(N+2*K)]
l = [model.NewIntVar(0, int(serve_time), f'l[{i}]') for i in range(N+2*K)]
y = model.NewIntVar(0, int(serve_time), 'y')

for i in range(N, N+K):
    model.Add(l[i]==0)

for i in range(K):
    model.Add(IR[N+i]-IR[N+K+i]==0)

for i in range(N+K):
    model.AddAllDifferent([x[i], i])

b=model.NewBoolVar('b')
for i in range(N+K):
    for j in range(N+2*K):
        b=model.NewBoolVar('b')
        model.Add(x[i]==j).OnlyEnforceIf(b)
        model.Add(x[i]!=j).OnlyEnforceIf(b.Not())
        model.Add(IR[i]-IR[j]==0).OnlyEnforceIf(b)
        model.Add(l[j]-l[i]==c[i][j]+d[j]).OnlyEnforceIf(b)

s = [x[i] for i in range(N+K)]
model.AddAllDifferent(s)
for i in range(N+K):
    for j in range(N, N+K):
        model.AddAllDifferent([x[i], j])
startIR = [IR[i] for i in range(N, N+K)]
model.AddAllDifferent(startIR)

f = [l[i] for i in range(N+K, N+2*K)]
for i in range(N+K, N+2*K):
    model.Add(y-l[i]>=0)
model.Minimize(y)
solver = cp_model.CpSolver()
status = solver.Solve(model)

assert status == cp_model.OPTIMAL
print('Minimum of objective function: %i\n' % solver.ObjectiveValue())
#     print()
#     print('x value: ', solver.Value(x))
#     print('y value: ', solver.Value(y))
#     print('z value: ', solver.Value(z))
for i in range(N, N+K):
    j=i
    print(f'Phu ta {j-N+1}: {i}   ', end='')
    while j<N+K:
        print(solver.Value(x[j]),  '   ', end='')
        j=solver.Value(x[j])
    print('\n')

# route = {}
# for k in range(K):
#     route[k] = [i for i in range(N+2*K) if solver.Value(IR[i])==k]
# print(route)