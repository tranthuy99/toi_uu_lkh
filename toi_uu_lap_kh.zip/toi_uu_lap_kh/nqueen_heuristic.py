def violation_pop():
    v=0
    for i in range(n-1):
        for j in range(i+1, n):
            if x[i]==x[j]:
                v+=1
            if x[i]+i==x[j]+j:
                v+=1
            if x[i]-i==x[j]-j:
                v+=1
    return v

def calcViolation(q):
    v=0
    for i in range(n):
        if i!=q:
            if x[i]==x[q]:
                v+=1
            if x[i]+i==x[q]+q:
                v+=1
            if x[i]-1==x[q]-q:
                v+=1
    return v

def calcViolationqr(q, r):
    v=0
    pass

def initial():
    for i in range(n):
        x[i]=0



def select_most_violation_queen():
    vio=[]
    for i in range(n):
        vio[i]=calcViolation(q)
    vio.argsort
    len=vio.count(vio[-1])
    for i in range()

def select_most_promissing_row(q):
    min_violation=calcVioltion(q)
    for v in range(n):
        if calcviolationqr(q, v)<min_violation:
            min_violation=calcViolationqr(q, v)
            vt=v
    return vt


def solve():
    initial()

    for k i range(1000):
        q=select_most_violation_queen()
        v=select_most_promissing_row(q)
        x[q]=v


n=20
violation=0
mr=[[0  for _ in range(n)] for __ in range(n)]
initial()
calcViolation(x)
