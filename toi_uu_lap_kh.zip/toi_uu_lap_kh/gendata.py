import random
def genData(filename, n):
    f=open(filename, 'w')
    f.write(str(n)+'\n')
    for i in range(n):
        s=''
        for j in range(n):
            x=random.randint(1,50)
            s=s+str(x)+' '
        s=s+'\n'
        f.write(s)
    f.close()

def input(filename):
    c=[]
    with open(filename, 'r') as f:
        n=int(f.readline())
        
        for i, con in enumerate(f.readlines()):
            c.append(con.strip().split(' '))
    return n, c
        
            
#genData('data_10.txt', 10)
print(input('data_10.txt'))